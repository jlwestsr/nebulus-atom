## Context Manager Walkthrough

1. Run `mini-nebulus start`
2. Execute `pin_file README.md`
3. Ask "What is in the pinned file?"
4. Verify the agent answers correctly based on context.
