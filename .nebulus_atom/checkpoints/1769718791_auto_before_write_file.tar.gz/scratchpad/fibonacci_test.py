import datetime
with open('.scratchpad/fibonacci_test.py', 'a') as f:
    f.write(str(datetime.datetime.now()))