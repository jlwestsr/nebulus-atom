import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up some constants
WIDTH, HEIGHT = 800, 600
SPEED = 10

# Create the game window
screen = pygame.display.set_mode((WIDTH, HEIGHT))

# Set up the snake and food
snake = [(200, 200), (220, 200), (240, 200)]
food = (400, 300)

# Game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Move the snake
    keys = pygame.key.get_pressed()
    if keys[pygame.K_UP]:
        snake.append((snake[-1][0], snake[-1][1] - 20))
    elif keys[pygame.K_DOWN]:
        snake.append((snake[-1][0], snake[-1][1] + 20))
    elif keys[pygame.K_LEFT]:
        snake.append((snake[-1][0] - 20, snake[-1][1]))
    elif keys[pygame.K_RIGHT]:
        snake.append((snake[-1][0] + 20, snake[-1][1]))

    # Check for collisions
    if (snake[-1][0] < 0 or snake[-1][0] >= WIDTH or
        snake[-1][1] < 0 or snake[-1][1] >= HEIGHT or
        snake[-1] in snake[:-1]):
        pygame.quit()
        sys.exit()

    # Draw everything
    screen.fill((0, 0, 0))
    for pos in snake:
        pygame.draw.rect(screen, (0, 255, 0), (pos[0], pos[1], 20, 20))
    pygame.draw.rect(screen, (255, 0, 0), (food[0], food[1], 20, 20))
    pygame.display.flip()
    pygame.time.Clock().tick(SPEED)
