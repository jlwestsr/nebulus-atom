from typing import Optional, Dict
from mini_nebulus.swarm.agents.router_agent import RouterAgent
from mini_nebulus.swarm.agents.coder_agent import CoderAgent
# from mini_nebulus.swarm.agents.architect_agent import ArchitectAgent
# from mini_nebulus.swarm.agents.tester_agent import TesterAgent
from mini_nebulus.utils.logger import setup_logger
from mini_nebulus.views.base_view import BaseView
from mini_nebulus.views.cli_view import CLIView
import json

logger = setup_logger(__name__)

class SwarmOrchestrator:
    def __init__(self, view: Optional[BaseView] = None):
        self.view = view if view else CLIView()
        
        # Init Agents
        self.router = RouterAgent()
        
        # Lazy load or init all agents
        # For now, we mainly use Coder as the default fallback
        self.agents = {
            "coder": CoderAgent(self.view),
            "architect": CoderAgent(self.view), # Placeholder: Architect is just Coder with different prompt?
            "tester": CoderAgent(self.view)   # Placeholder
        }
        
    async def start(self, initial_prompt: Optional[str] = None, session_id: str = "default"):
        await self.view.print_welcome()
        if hasattr(self.view, "start_app"):
             # TUI mode needs special handling, but for now we run CLI flow if TUI is not fully swarm-aware
             pass

        if initial_prompt:
             await self.process_request(initial_prompt, session_id)

    async def process_request(self, user_input: str, session_id: str):
        # 1. Route
        if hasattr(self.view, "print_agent_response"):
            await self.view.print_agent_response("🔄 [Swarm] Routing request...")
            
        routing_json = await self.router.process_turn(session_id, user_input)
        
        try:
            decision = json.loads(routing_json)
            target_agent_name = decision.get("agent", "coder")
            reasoning = decision.get("reasoning", "Defaulting to Coder")
        except:
            target_agent_name = "coder"
            reasoning = "Router failed JSON parsing"

        if hasattr(self.view, "print_agent_response"):
            await self.view.print_agent_response(f"👉 Handoff to **{target_agent_name.upper()}**: {reasoning}")

        # 2. Handoff
        agent = self.agents.get(target_agent_name, self.agents["coder"])
        
        # 3. Execute
        # We need to bridge the CoderAgent (which is basically AgentController) to run its loop
        # Since I'm reusing AgentController code for CoderAgent, I need to make sure CoderAgent.process_turn works similar
        
        # NOTE: CoderAgent is special because it's interactive.
        # We might just call agent.process_turn(session_id, user_input)
        
        if hasattr(agent, "handle_tui_input"):
             # It's an interactive controller
             # Inject the input into history first
             agent.history_manager.get_session(session_id).add("user", user_input)
             await agent.process_turn(session_id)
