import subprocess
import asyncio
from mini_nebulus.services.file_service import FileService
from mini_nebulus.services.task_service import TaskServiceManager
from mini_nebulus.services.skill_service import SkillService
from mini_nebulus.services.context_service import ContextServiceManager
from mini_nebulus.services.checkpoint_service import CheckpointServiceManager
from mini_nebulus.services.rag_service import RagServiceManager
from mini_nebulus.models.task import TaskStatus
from mini_nebulus.utils.logger import setup_logger

logger = setup_logger(__name__)


class ToolExecutor:
    task_manager = TaskServiceManager()
    context_manager = ContextServiceManager()
    skill_service = SkillService()
    checkpoint_manager = CheckpointServiceManager()
    rag_manager = RagServiceManager()

    @staticmethod
    def initialize():
        """Initial load of skills."""
        ToolExecutor.skill_service.load_skills()

    @staticmethod
    async def dispatch(tool_name: str, args: dict, session_id: str = "default"):
        logger.info(
            f"Dispatching tool '{tool_name}' with args: {str(args)[:200]}..."
        )  # Truncate args for log safety
        try:
            task_service = ToolExecutor.task_manager.get_service(session_id)
            context_service = ToolExecutor.context_manager.get_service(session_id)
            checkpoint_service = ToolExecutor.checkpoint_manager.get_service(session_id)
            rag_service = ToolExecutor.rag_manager.get_service(session_id)

            # Auto-Checkpoint for destructive operations
            if tool_name == "write_file":
                checkpoint_service.create_checkpoint(label=f"auto_before_{tool_name}")

            # Shell Tools
            if tool_name == "run_shell_command":
                return await ToolExecutor.run_shell_command(args.get("command"))

            # File Tools
            elif tool_name == "read_file":
                return FileService.read_file(args.get("path"))
            elif tool_name == "write_file":
                return FileService.write_file(args.get("path"), args.get("content"))
            elif tool_name == "list_dir":
                return str(FileService.list_dir(args.get("path", ".")))

            # Context Tools
            elif tool_name == "pin_file":
                return context_service.pin_file(args.get("path"))
            elif tool_name == "unpin_file":
                return context_service.unpin_file(args.get("path"))
            elif tool_name == "list_context":
                return str(context_service.list_context())

            # Checkpoint Tools
            elif tool_name == "create_checkpoint":
                return checkpoint_service.create_checkpoint(args.get("label", "manual"))
            elif tool_name == "rollback_checkpoint":
                return checkpoint_service.rollback_checkpoint(args.get("id"))
            elif tool_name == "list_checkpoints":
                return checkpoint_service.list_checkpoints()

            # RAG Tools
            elif tool_name == "index_codebase":
                return rag_service.index_codebase()
            elif tool_name == "search_code":
                return str(rag_service.search_code(args.get("query")))

            # Task Tools
            elif tool_name == "create_plan":
                plan = task_service.create_plan(args.get("goal"))
                return f"Plan created for goal: {plan.goal}. ID: {plan.id}"
            elif tool_name == "add_task" or tool_name == "create_task":
                task = task_service.add_task(
                    args.get("description"), args.get("dependencies")
                )
                return f"Task added: {task.description}. ID: {task.id}"
            elif tool_name == "update_task":
                status_str = args.get("status", "").upper()
                try:
                    status = TaskStatus[status_str]
                except KeyError:
                    return f"Invalid status: {status_str}. Valid: {list(TaskStatus.__members__.keys())}"

                task_service.update_task_status(
                    args.get("task_id"), status, args.get("result", "")
                )
                return f"Task {args.get('task_id')} updated to {status.value}"
            elif tool_name == "get_plan":
                return task_service.get_plan_data()

            # Skill Tools
            elif tool_name == "create_skill":
                name = args.get("name")
                code = args.get("code")
                filename = f"mini_nebulus/skills/{name}.py"
                FileService.write_file(filename, code)
                ToolExecutor.skill_service.load_skills()  # Hot reload
                return f"Skill {name} created and loaded from {filename}"
            elif tool_name == "publish_skill":
                return ToolExecutor.skill_service.publish_skill(args.get("name"))
            elif tool_name == "refresh_skills":
                ToolExecutor.skill_service.load_skills()
                return "Skills reloaded."

            # Dynamic Skills
            elif tool_name in ToolExecutor.skill_service.skills:
                return ToolExecutor.skill_service.execute_skill(tool_name, args)

            else:
                logger.warning(f"Attempted to execute unknown tool: {tool_name}")
                return f"Unknown tool: {tool_name}"
        except Exception as e:
            logger.error(f"Error executing {tool_name}: {str(e)}", exc_info=True)
            return f"Error executing {tool_name}: {str(e)}"

    @staticmethod
    async def run_shell_command(command: str) -> str:
        if not command:
            return "Error: No command provided"
        try:
            process = await asyncio.create_subprocess_shell(
                command, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            stdout, stderr = await process.communicate()

            output = stdout.decode().strip()
            if stderr:
                output += "\n" + stderr.decode().strip()

            return output if output.strip() else "(no output)"
        except Exception as e:
            return f"Error: {str(e)}"
