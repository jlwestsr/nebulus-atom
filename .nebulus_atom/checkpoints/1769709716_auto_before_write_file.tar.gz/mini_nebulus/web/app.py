import streamlit as st
import asyncio
import websockets
import json
import requests
from datetime import datetime

# Configuration
API_URL = "http://mini-nebulus-core:8000"
WS_URL = "ws://mini-nebulus-core:8000/ws"

st.set_page_config(page_title="Mini-Nebulus", page_icon="🌌", layout="wide")

# --- Security: Basic Auth ---
import secrets
import os

def check_password():
    """Returns `True` if the user had a correct password."""
    
    # Load secrets from Environment (Docker/OS)
    # Default to secure values if not set to prevent open access in prod
    EXPECTED_USER = os.environ.get("WEB_UI_USERNAME", "admin")
    EXPECTED_PASS = os.environ.get("WEB_UI_PASSWORD", "nebulus")

    def password_entered():
        """Checks whether a password entered by the user is correct."""
        if (
            st.session_state["username"] == EXPECTED_USER
            and st.session_state["password"] == EXPECTED_PASS
        ):
            st.session_state["password_correct"] = True
            # Keep credentials in state to avoid KeyErrors during auto-reruns
        else:
            st.session_state["password_correct"] = False

    if "password_correct" not in st.session_state:
        # First run, show inputs
        st.text_input("Username", on_change=password_entered, key="username")
        st.text_input("Password", type="password", on_change=password_entered, key="password")
        return False
    elif not st.session_state["password_correct"]:
        # Password not correct, show input + error
        st.text_input("Username", on_change=password_entered, key="username")
        st.text_input("Password", type="password", on_change=password_entered, key="password")
        st.error("😕 User not known or password incorrect")
        return False
    else:
        # Password correct
        return True

if not check_password():
    st.stop()
# -----------------------------

# Custom CSS for "Gemini Dark Mode" feel
st.markdown("""
<style>
    .stApp {
        background-color: #0e1117;
    }
    .chat-message {
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 1rem;
        display: flex;
        flex-direction: column;
    }
    .user-msg {
        background-color: #2b313e;
        border-left: 5px solid #a855f7;
    }
    .agent-msg {
        background-color: #1e293b;
        border-left: 5px solid #10b981;
    }
    .tool-output {
        font-family: monospace;
        font-size: 0.85em;
        background-color: #0f172a;
        color: #94a3b8;
        padding: 0.5rem;
        margin-top: 0.5rem;
        border-radius: 4px;
    }
</style>
""", unsafe_allow_html=True)

# Session State
if "messages" not in st.session_state:
    st.session_state.messages = []
if "plan" not in st.session_state:
    st.session_state.plan = {}
if "logs" not in st.session_state:
    st.session_state.logs = []

# Sidebar - Plan & Status
with st.sidebar:
    st.title("🌌 Mini-Nebulus")
    st.markdown("---")
    
    if st.session_state.plan:
        st.subheader(f"🎯 Goal: {st.session_state.plan.get('goal', 'None')}")
        tasks = st.session_state.plan.get('tasks', [])
        for task in tasks:
            icon = "⏳"
            if task['status'] == "completed": icon = "✅"
            elif task['status'] == "in_progress": icon = "🔄"
            elif task['status'] == "failed": icon = "❌"
            st.markdown(f"{icon} {task['description']}")
    else:
        st.info("No active plan.")

    st.markdown("---")
    st.subheader("📝 Live Logs")
    log_container = st.container(height=300)
    for log in st.session_state.logs[-20:]:  # Last 20 logs
        log_container.text(log)

# Main Chat Interface
st.header("Agent Chat")

# Render History
for msg in st.session_state.messages:
    if msg["role"] == "user":
        st.markdown(f"""<div class="chat-message user-msg"><b>User:</b> {msg['content']}</div>""", unsafe_allow_html=True)
    else:
        # Check if it has tool output
        tools = msg.get("tools", [])
        tool_html = ""
        for tool in tools:
            tool_html += f"""<div class="tool-output">🔧 {tool['name']}: {tool['output'][:200]}...</div>"""
            
        st.markdown(f"""
        <div class="chat-message agent-msg">
            <b>Agent:</b> {msg['content']}
            {tool_html}
        </div>
        """, unsafe_allow_html=True)

# Input
prompt = st.chat_input("Say something...")
if prompt:
    # Optimistic Update
    st.session_state.messages.append({"role": "user", "content": prompt})
    try:
        requests.post(f"{API_URL}/chat", json={"message": prompt})
    except Exception as e:
        st.error(f"Failed to send message: {e}")
    st.rerun()

# --- Event Logic ---
import time

def handle_event(event):
    if event['type'] == 'agent_response':
        st.session_state.messages.append({"role": "assistant", "content": event['data']['text']})
    
    elif event['type'] == 'plan_update':
        st.session_state.plan = event['data']
    
    elif event['type'] == 'tool_output':
         st.session_state.logs.append(f"🔧 {event['data']['tool']} -> {event['data']['output'][:100]}...")
    
    elif event['type'] == 'spinner':
        status = event['data'].get('status')
        text = event['data'].get('text', '')
        if status == 'start':
            st.session_state.logs.append(f"⏳ {text}")
        elif status == 'stop':
            st.session_state.logs.append(f"✔ Done")

def poll_events():
    """Fetch pending events from API and update state."""
    try:
        response = requests.get(f"{API_URL}/events", timeout=30)
        if response.status_code == 200:
            events = response.json()
            if events:
                for event in events:
                    handle_event(event)
                return True
        else:
            st.sidebar.error(f"Poll Error: {response.status_code}")
    except Exception as e:
        st.sidebar.error(f"Poll Failed: {e}")
    return False

# --- Auto-Refresh / Polling Loop ---
if st.sidebar.toggle("Live Updates", value=True):
    st.sidebar.caption("Polling active...")
    poll_events()
    time.sleep(1)
    st.rerun()
else:
    st.sidebar.caption("Polling paused.")
    if st.sidebar.button("Manual Refresh"):
        poll_events()
        st.rerun()
