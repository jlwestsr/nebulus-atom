import datetime
print(datetime.datetime.now())