
import asyncio
import json
from openai import AsyncOpenAI
from mini_nebulus.controllers.agent_controller import AgentController

async def test_manual_prompt():
    print("Initializing AgentController to get tools...")
    controller = AgentController()
    tools_json = json.dumps([t['function'] for t in controller.get_current_tools()], indent=2)
    
    try:
        with open("CONTEXT.md", "r") as f:
            context_content = f.read()
    except:
        context_content = "Context file not found."

    system_prompt = (
        "You are Mini-Nebulus. Use tools to perform actions.\n"
        "### PROJECT CONTEXT ###\n"
        f"{context_content}\n\n"
        "### AVAILABLE TOOLS ###\n"
        f"{tools_json}"
    )
    
    client = AsyncOpenAI(
        base_url="http://localhost:5000/v1",
        api_key="admin"
    )
    
    print("Sending request with INJECTED prompt (no native tools)...")
    try:
        stream = await client.chat.completions.create(
            model="Meta-Llama-3.1-8B-Instruct-exl2-8_0",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": "Create a file named hello.txt"}
            ],
            stream=True
        )
        async for chunk in stream:
            print(chunk.choices[0].delta.content or "", end="", flush=True)
        print("\nSuccess!")
    except Exception as e:
        print(f"\nError: {e}")

if __name__ == "__main__":
    asyncio.run(test_manual_prompt())
