import pytest
import sys
import os
from unittest.mock import MagicMock, patch

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_dependencies_installed():
    """Verify that UI dependencies are importable."""
    try:
        import textual
        import streamlit
        import pandas
    except ImportError as e:
        pytest.fail(f"Missing dependency: {e}")

def test_tui_view_initialization():
    """Verify TextualView can be instantiated."""
    # We might need to mock Textual's App init if it does heavy lifting
    with patch('textual.app.App.__init__', return_value=None):
        from mini_nebulus.views.tui_view import TextualView
        view = TextualView()
        assert hasattr(view, 'compose')
        assert hasattr(view, 'set_controller')

def test_dashboard_file_exists():
    """Verify dashboard.py exists."""
    dashboard_path = os.path.join(
        os.path.dirname(__file__), "../../mini_nebulus/ui/dashboard.py"
    )
    assert os.path.exists(dashboard_path), "dashboard.py not found"

def test_dashboard_command_import():
    """Verify main.py has the dashboard command."""
    from mini_nebulus.main import app
    # access local commands via internal storage or just check it imports
    import mini_nebulus.main as main_module
    assert hasattr(main_module, 'dashboard')
