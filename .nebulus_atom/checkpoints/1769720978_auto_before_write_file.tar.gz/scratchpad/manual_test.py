
import asyncio
from openai import AsyncOpenAI

async def test_connection():
    client = AsyncOpenAI(
        base_url="http://localhost:5000/v1",
        api_key="admin"
    )
    
    print("Testing connection...")
    try:
        stream = await client.chat.completions.create(
            model="Meta-Llama-3.1-8B-Instruct-exl2-8_0",
            messages=[{"role": "user", "content": "Hello"}],
            stream=True
        )
        async for chunk in stream:
            print(chunk.choices[0].delta.content or "", end="", flush=True)
        print("\nSuccess!")
    except Exception as e:
        print(f"\nError: {e}")

if __name__ == "__main__":
    asyncio.run(test_connection())
